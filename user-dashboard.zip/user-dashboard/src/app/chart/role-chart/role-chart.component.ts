import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { UserService } from 'src/app/services/user.service';




@Component({
  selector: 'app-role-chart',
  template: `<canvas id="roleChart"></canvas>`
})



export class RoleChartComponent implements OnInit, OnDestroy {

  private chart: any;
  private sub!: Subscription;

  constructor(private userService: UserService) {}



  async ngOnInit() {
    const Chart = (await import('chart.js/auto')).default;

    this.sub = this.userService.users$.subscribe(users => {
      const roleCount = {
        Admin: 0,
        Editor: 0,
        Viewer: 0
      };

      users.forEach(user => roleCount[user.role]++);

      if (this.chart) {
        this.chart.destroy();
      }

      this.chart = new Chart('roleChart', {
        type: 'pie',
        data: {
          labels: Object.keys(roleCount),
          datasets: [
            {
              data: Object.values(roleCount),
              backgroundColor: ['#1c4980', '#383838', '#9e9e9e']
            }
          ]
        }
      });
    });
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
    if (this.chart) {
      this.chart.destroy();
    }
  }
}
