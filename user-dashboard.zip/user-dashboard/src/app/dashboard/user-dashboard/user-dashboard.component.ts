import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from 'src/app/models/user';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent {

  users$: Observable<User[]>;
  showForm = false;
  isLoading = false;


  constructor(private userService: UserService) {
    this.users$ = this.userService.users$;
  }

  openForm() {
    this.showForm = true;
  }

  closeForm() {
    this.showForm = false;
  }

  addUser(user: User) {
    this.userService.addUser(user);
    this.closeForm();
  }
}
