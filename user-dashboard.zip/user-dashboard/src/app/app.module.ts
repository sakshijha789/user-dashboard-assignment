import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { UserDashboardComponent } from './dashboard/user-dashboard/user-dashboard.component';
import { UserFormComponent } from './user-form/user-form.component';
import { RoleChartComponent } from './chart/role-chart/role-chart.component';

@NgModule({
  declarations: [
    AppComponent,
    UserDashboardComponent,
    UserFormComponent,
    RoleChartComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
